""" 
common stuff for gluing things together and hiding unnecessary complexity  
"""